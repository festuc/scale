-- Adminer 4.7.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP DATABASE IF EXISTS `devel`;
CREATE DATABASE `devel` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;
USE `devel`;

DELIMITER ;;

CREATE FUNCTION `URLDECODER`(str VARCHAR(4096) CHARSET utf8) RETURNS varchar(4096) CHARSET utf8
    DETERMINISTIC
BEGIN
               DECLARE X  INT;               
               DECLARE chr VARCHAR(256);
               DECLARE chrto VARCHAR(256);
               DECLARE result VARCHAR(4096);
               SET X = 1;
               WHILE X  <= (SELECT MAX(id) FROM urlcodemap) DO
                   SET chr = (SELECT `encoded` FROM urlcodemap WHERE id = X);
                   SET chrto = (SELECT `decoded` FROM urlcodemap WHERE id = X);                
                           SET str = REPLACE(str,chr,chrto);
                           SET  X = X + 1;                           
               END WHILE;
               RETURN str;
       END;;

DELIMITER ;

DROP TABLE IF EXISTS `100_Venedor`;
CREATE TABLE `100_Venedor` (
  `ID` tinyint(3) unsigned NOT NULL,
  `Value` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `100_Venedor`;
INSERT INTO `100_Venedor` (`ID`, `Value`) VALUES
(0,	'Venda al major'),
(1,	'Jon Doe'),
(2,	'Pere Pi');

DROP TABLE IF EXISTS `2021_Empresa_100_index_relacio`;
CREATE TABLE `2021_Empresa_100_index_relacio` (
  `ID` int(11) NOT NULL,
  `ID_client` int(11) NOT NULL,
  `ID_tipus_relacio` int(11) NOT NULL,
  `ID_Venedor` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `ID_Pagament` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `tax_detall` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `editable` tinyint(4) unsigned NOT NULL DEFAULT 1,
  `relacio_oberta` tinyint(4) unsigned NOT NULL DEFAULT 1,
  `data` date NOT NULL DEFAULT current_timestamp(),
  `equivalency_charge` int(11) NOT NULL DEFAULT 0,
  `fiscal_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `NIF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `fiscal_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `Poblacio` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comercial_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `deliver_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`,`ID_tipus_relacio`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `ID_tipus_relacio` (`ID_tipus_relacio`),
  KEY `ID_Pagament` (`ID_Pagament`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

TRUNCATE `2021_Empresa_100_index_relacio`;

DROP TABLE IF EXISTS `2021_Empresa_100_line`;
CREATE TABLE `2021_Empresa_100_line` (
  `ID` bigint(20) unsigned NOT NULL COMMENT 'id de relació',
  `ID_tipus_relacio` int(11) NOT NULL,
  `line` int(10) unsigned NOT NULL COMMENT 'numero de línea',
  `ID_product` int(10) unsigned NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `units` decimal(6,3) NOT NULL,
  `bulk` tinyint(3) unsigned DEFAULT 1,
  `cost` float(25,10) NOT NULL,
  `IVA` decimal(6,2) NOT NULL COMMENT '% d''iva',
  `EQUIVALENCY_CHARGE` decimal(6,2) NOT NULL DEFAULT 0.00 COMMENT '% RECARREG',
  `hidden_now` datetime NOT NULL,
  `lotnumber` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `discount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '% de descompte',
  `deleted_line` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT 'la linea ha estat eliminada',
  PRIMARY KEY (`ID`,`ID_tipus_relacio`,`line`),
  KEY `ID_tipus_relacio` (`ID_tipus_relacio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

TRUNCATE `2021_Empresa_100_line`;

DROP TABLE IF EXISTS `Clients`;
CREATE TABLE `Clients` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Nom Cognoms/ raó social',
  `fiscal_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Adreça Fiscal',
  `Poblacio` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Codi postal, població',
  `NIF` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bool_equivalency_charge` int(11) NOT NULL DEFAULT 0 COMMENT 'Paga recàrreg d''equivalència?',
  `bool_Active` int(11) NOT NULL DEFAULT 1 COMMENT 'Accepta protecció dades?',
  `id_tarifa` int(11) DEFAULT 10 COMMENT 'Tarifa',
  `bool_tax_detall` int(11) DEFAULT 1 COMMENT 'Vol l''IVA desglosat?',
  `comercial_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Nom comercial',
  `deliver_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Adreça d''entrega',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Correu electrònic',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NIF` (`NIF`),
  KEY `id_tarifa` (`id_tarifa`),
  CONSTRAINT `Clients_ibfk_1` FOREIGN KEY (`id_tarifa`) REFERENCES `tarifa` (`ID`) ON DELETE NO ACTION,
  CONSTRAINT `Clients_ibfk_2` FOREIGN KEY (`id_tarifa`) REFERENCES `tarifa` (`ID`),
  CONSTRAINT `Clients_ibfk_3` FOREIGN KEY (`id_tarifa`) REFERENCES `tarifa` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2029 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

TRUNCATE `Clients`;
INSERT INTO `Clients` (`ID`, `Value`, `fiscal_address`, `Poblacio`, `NIF`, `bool_equivalency_charge`, `bool_Active`, `id_tarifa`, `bool_tax_detall`, `comercial_name`, `deliver_address`, `email`) VALUES
(1,	'Pere Pi de les Tres Branques',	'C/ Major',	'25888 Sant Esteve dels Roures',	'26xxx444',	0,	1,	1,	1,	'',	'',	'perepi%developement.yourcompany.com');

DROP TABLE IF EXISTS `Clients_phone`;
CREATE TABLE `Clients_phone` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ID_Client` int(11) NOT NULL,
  `Value` varchar(255) NOT NULL,
  `prefered` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Value` (`Value`),
  KEY `ID_Client` (`ID_Client`),
  CONSTRAINT `Clients_phone_ibfk_1` FOREIGN KEY (`ID_Client`) REFERENCES `Clients` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

TRUNCATE `Clients_phone`;
INSERT INTO `Clients_phone` (`ID`, `ID_Client`, `Value`, `prefered`) VALUES
(35,	1,	'+151234555',	0);

DROP TABLE IF EXISTS `dealers`;
CREATE TABLE `dealers` (
  `ID` int(10) unsigned NOT NULL,
  `Value` varchar(255) NOT NULL,
  `hidden_user` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `dealers`;
INSERT INTO `dealers` (`ID`, `Value`, `hidden_user`) VALUES
(1,	'Producte+intern',	'');

DROP TABLE IF EXISTS `ean`;
CREATE TABLE `ean` (
  `ID` int(11) NOT NULL,
  `Value` decimal(13,0) NOT NULL,
  KEY `ID_Value` (`ID`,`Value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `ean`;

DROP TABLE IF EXISTS `Empresa`;
CREATE TABLE `Empresa` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Direccio` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Poblacio` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NIF` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `termal_head_1` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `termal_head_2` varchar(35) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `termal_head_3` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `termal_tail_1` varchar(35) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sticker_printer` varchar(35) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `a4_printer` varchar(35) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `printerserver` varchar(35) COLLATE utf8mb4_unicode_ci DEFAULT 'localhost',
  `telegram_relacions` varchar(35) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scale_uri` varchar(35) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `caixa_uri` varchar(35) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'si té les bascules antigues i hem de conectar al cashkeeper',
  `cashkeeper` varchar(35) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'windows que el controla',
  `ID_Empresa_a_mxgestio` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

TRUNCATE `Empresa`;
INSERT INTO `Empresa` (`ID`, `Value`, `Direccio`, `Poblacio`, `Phone`, `email`, `NIF`, `termal_head_1`, `termal_head_2`, `termal_head_3`, `termal_tail_1`, `sticker_printer`, `a4_printer`, `printerserver`, `telegram_relacions`, `scale_uri`, `caixa_uri`, `cashkeeper`, `ID_Empresa_a_mxgestio`) VALUES
(0,	'TRIA EMPRESA',	'',	'',	'',	'',	'',	'',	'',	'',	'',	'',	'',	'festuc@localhost',	'',	'',	'',	'',	0),
(100,	'Developement Company',	'some where over the rainbow',	'555888 Milky Way',	'NAN',	'devcomp@developement.yourcompany.com',	'NOVALID',	'Developement',	'  Algun lloc de la galàxia',	'Via làctea S/N         555999333',	'www.yourcompany.com',	'etiquetes',	'printer',	'dev@devserver',	'',	'https://dev.yourcompany.com/scale',	'',	'',	0);

DROP TABLE IF EXISTS `equivalency_charge`;
CREATE TABLE `equivalency_charge` (
  `ID_iva` int(10) unsigned NOT NULL COMMENT 'PER CADA IVA HI HA UNA TAXA',
  `TAX` decimal(6,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

TRUNCATE `equivalency_charge`;
INSERT INTO `equivalency_charge` (`ID_iva`, `TAX`) VALUES
(0,	1.40),
(1,	0.50),
(2,	5.20),
(3,	0.00);

DROP TABLE IF EXISTS `families`;
CREATE TABLE `families` (
  `ID` int(11) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `families`;
INSERT INTO `families` (`ID`, `value`) VALUES
(1,	'Fruits Secs'),
(9999,	'Altres');

DROP TABLE IF EXISTS `imprimeix`;
CREATE TABLE `imprimeix` (
  `ID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `ID_product` int(11) NOT NULL,
  `units` smallint(6) NOT NULL,
  `preu_or_etiqueta` tinyint(4) NOT NULL COMMENT '0 preu 1 etiqueta',
  PRIMARY KEY (`ID`)
) ENGINE=MEMORY AUTO_INCREMENT=525 DEFAULT CHARSET=utf8;

TRUNCATE `imprimeix`;

DROP TABLE IF EXISTS `IVA`;
CREATE TABLE `IVA` (
  `ID` tinyint(3) unsigned NOT NULL,
  `Value` decimal(6,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `IVA`;
INSERT INTO `IVA` (`ID`, `Value`) VALUES
(0,	10.00),
(1,	4.00),
(2,	21.00),
(3,	0.00);

DROP VIEW IF EXISTS `llistapvp`;
CREATE TABLE `llistapvp` (`id` varchar(4), `value` varchar(40), `cost` varchar(10), `pvp` varchar(10), `pv1` varchar(10), `pv2` varchar(10), `pv3` varchar(10), `pv4` varchar(10), `modificat` varchar(11), `datacrua` datetime);


DROP VIEW IF EXISTS `Llista_prov`;
CREATE TABLE `Llista_prov` (`Proveïdor` text);


DROP TABLE IF EXISTS `meta_index_relacio`;
CREATE TABLE `meta_index_relacio` (
  `ID` int(11) NOT NULL,
  `ID_client` int(11) NOT NULL,
  `ID_tipus_relacio` int(11) NOT NULL,
  `ID_Venedor` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `ID_Pagament` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `tax_detall` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `editable` tinyint(4) unsigned NOT NULL DEFAULT 1,
  `relacio_oberta` tinyint(4) unsigned NOT NULL DEFAULT 1,
  `data` date NOT NULL DEFAULT current_timestamp(),
  `equivalency_charge` int(11) NOT NULL DEFAULT 0,
  `fiscal_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `NIF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `fiscal_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `Poblacio` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comercial_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `deliver_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`,`ID_tipus_relacio`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `ID_tipus_relacio` (`ID_tipus_relacio`),
  KEY `ID_Pagament` (`ID_Pagament`),
  CONSTRAINT `meta_index_relacio_ibfk_1` FOREIGN KEY (`ID_tipus_relacio`) REFERENCES `tipus_relacio` (`ID`),
  CONSTRAINT `meta_index_relacio_ibfk_2` FOREIGN KEY (`ID_Pagament`) REFERENCES `Pagament` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

TRUNCATE `meta_index_relacio`;

DROP TABLE IF EXISTS `meta_line`;
CREATE TABLE `meta_line` (
  `ID` bigint(20) unsigned NOT NULL COMMENT 'id de relació',
  `ID_tipus_relacio` int(11) NOT NULL,
  `line` int(10) unsigned NOT NULL COMMENT 'numero de línea',
  `ID_product` int(10) unsigned NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `units` decimal(6,3) NOT NULL,
  `bulk` tinyint(3) unsigned DEFAULT 1,
  `cost` float(25,10) NOT NULL,
  `IVA` decimal(6,2) NOT NULL COMMENT '% d''iva',
  `EQUIVALENCY_CHARGE` decimal(6,2) NOT NULL DEFAULT 0.00 COMMENT '% RECARREG',
  `hidden_now` datetime NOT NULL,
  `lotnumber` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `discount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '% de descompte',
  `deleted_line` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT 'la linea ha estat eliminada',
  PRIMARY KEY (`ID`,`ID_tipus_relacio`,`line`),
  KEY `ID_tipus_relacio` (`ID_tipus_relacio`),
  CONSTRAINT `meta_line_ibfk_2` FOREIGN KEY (`ID_tipus_relacio`) REFERENCES `tipus_relacio` (`ID`) ON DELETE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

TRUNCATE `meta_line`;

DROP TABLE IF EXISTS `Pagament`;
CREATE TABLE `Pagament` (
  `ID` tinyint(3) unsigned NOT NULL,
  `Value` varchar(255) NOT NULL,
  `ID_tipus_relacio` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID_tipus_relacio` (`ID_tipus_relacio`),
  CONSTRAINT `Pagament_ibfk_1` FOREIGN KEY (`ID_tipus_relacio`) REFERENCES `tipus_relacio` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `Pagament`;
INSERT INTO `Pagament` (`ID`, `Value`, `ID_tipus_relacio`) VALUES
(0,	'No pagat',	0),
(1,	'Efectiu',	3),
(2,	'Tarjeta TPV',	3),
(10,	'Pendent <-cal autorització',	3),
(11,	'Pressupost',	5),
(12,	'Albarà',	2),
(13,	'Inventari',	6),
(14,	'Comanda ',	7),
(15,	'traspàs entre botigues',	8);

DROP TABLE IF EXISTS `productnames`;
CREATE TABLE `productnames` (
  `ID` int(11) NOT NULL,
  `lang` varchar(4) NOT NULL DEFAULT 'ca',
  `value` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `productnames`;
INSERT INTO `productnames` (`ID`, `lang`, `value`) VALUES
(1,	'ca',	'AMETLLA TORRADA');

DROP TABLE IF EXISTS `productnamesurlencoded`;
CREATE TABLE `productnamesurlencoded` (
  `ID` int(11) NOT NULL,
  `lang` varchar(4) NOT NULL DEFAULT 'ca',
  `value` varchar(40) NOT NULL,
  `origen` varchar(255) NOT NULL DEFAULT 'Espanya EU' COMMENT 'description1 \\n',
  `ingredients` text NOT NULL DEFAULT 'Producte Natural' COMMENT 'description2 \\n',
  `advertencia` text NOT NULL DEFAULT 'Pot contenir traces de cacauet, altres fruits secs, gluten, sèsam i soja (degut a la manipulació en el mateix establiment). Protegir de la llum solar. Preservar d\'olors agressius. Conservar en un lloc net, fresc i sec.' COMMENT 'description3 \\n',
  `link-rewrite` varchar(40) NOT NULL DEFAULT './',
  `aviable_now` varchar(40) NOT NULL DEFAULT '1',
  `descriptionshort` text NOT NULL DEFAULT 'L\'ametlla torrada és un dels nostres productes estrella! Les torrem amb foc de llenya al seu punt just amb una mica de sal perquè es puguin pelar fàcilment. Fruit carregat d\'història i tradició, l\'ametlla té un extraordinari poder nutritiu. Conté una quantitat notable de fibra soluble (10%) de manera que és ideal per estimular els moviments intestinals i per conferir sensació de sacietat. Ajuden a la regeneració del sistema nervios, estrès, depresió, cansanci intelectual o físic. Això és degut a l’equilibri adequat entre el calci, magnesi i potassi, conserva el to muscular i evita la irritabilitat nerviosa. A més la seva riquesa en fòsfor i àcids grassos poliinsaturats afavoreix la producció de fosfolípids, essencials per les membranes cel·lulars de les neurones.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `productnamesurlencoded`;
INSERT INTO `productnamesurlencoded` (`ID`, `lang`, `value`, `origen`, `ingredients`, `advertencia`, `link-rewrite`, `aviable_now`, `descriptionshort`) VALUES
(1,	'ca',	'Ametlla+Torrada',	'Espanya EU',	'\'Producte Natural\'',	'\'Pot contenir traces de cacauet, altres fruits secs, gluten, sèsam i soja (degut a la manipulació en el mateix establiment). Protegir de la llum solar. Preservar d\\\'olors agressius. Conservar en un lloc net, fresc i sec.\'',	'./',	'1',	'\'L\\\'ametlla torrada és un dels nostres productes estrella! Les torrem amb foc de llenya al seu punt just amb una mica de sal perquè es puguin pelar fàcilment. Fruit carregat d\\\'història i tradició, l\\\'ametlla té un extraordinari poder nutritiu. Conté una quantitat notable de fibra soluble (10%) de manera que és ideal per estimular els moviments intestinals i per conferir sensació de sacietat. Ajuden a la regeneració del sistema nervios, estrès, depresió, cansanci intelectual o físic. Això és degut a l’equilibri adequat entre el calci, magnesi i potassi, conserva el to muscular i evita la irritabilitat nerviosa. A més la seva riquesa en fòsfor i àcids grassos poliinsaturats afavoreix la producció de fosfolípids, essencials per les membranes cel·lulars de les neurones.\'');

DROP VIEW IF EXISTS `scalelist`;
CREATE TABLE `scalelist` (`id` int(11), `value` varchar(40), `exist` varchar(1), `formatpvp` varchar(16), `bulk` tinyint(4), `pvp` decimal(9,2));


DROP TABLE IF EXISTS `SingInAtWork`;
CREATE TABLE `SingInAtWork` (
  `ID` varchar(255) NOT NULL,
  `ID_Empresa` int(10) unsigned NOT NULL,
  `diahora` datetime NOT NULL,
  KEY `ID_Empresa` (`ID_Empresa`),
  CONSTRAINT `SingInAtWork_ibfk_1` FOREIGN KEY (`ID_Empresa`) REFERENCES `Empresa` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `SingInAtWork`;

DROP TABLE IF EXISTS `tarifa`;
CREATE TABLE `tarifa` (
  `ID` int(11) NOT NULL,
  `Value` varchar(255) NOT NULL,
  `lang` varchar(255) NOT NULL DEFAULT 'ca',
  `column_name` varchar(255) NOT NULL DEFAULT 'pvp',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `tarifa`;
INSERT INTO `tarifa` (`ID`, `Value`, `lang`, `column_name`) VALUES
(0,	'--',	'ca',	'pvp'),
(1,	'Tarifa 1000',	'ca',	'pv1'),
(2,	'Tarifa 2000',	'ca',	'pv2'),
(3,	'Tarifa 3000',	'ca',	'pv3'),
(4,	'Tarifa 4000',	'ca',	'pv4'),
(10,	'Tarifa PVP',	'ca',	'pvp');

DROP TABLE IF EXISTS `tarifes`;
CREATE TABLE `tarifes` (
  `ID` int(10) unsigned NOT NULL,
  `data_hora` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user` varchar(255) NOT NULL,
  `id_dealer` int(11) NOT NULL,
  `id_familia` int(11) NOT NULL,
  `bool_in_bulk` tinyint(4) NOT NULL DEFAULT 1,
  `cost_price` decimal(8,2) NOT NULL,
  `pvp` decimal(8,2) NOT NULL,
  `pvpi` varchar(255) NOT NULL,
  `pv1` decimal(8,2) NOT NULL,
  `pv1i` varchar(255) NOT NULL,
  `pv2` decimal(8,2) NOT NULL,
  `pv2i` varchar(255) NOT NULL,
  `pv3` decimal(8,2) NOT NULL,
  `pv3i` varchar(255) NOT NULL,
  `pv4` decimal(8,2) NOT NULL,
  `pv4i` varchar(255) NOT NULL,
  `historic` int(10) unsigned NOT NULL DEFAULT 1,
  `ultimpreu` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `tipusiva` tinyint(3) unsigned NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `tarifes`;
INSERT INTO `tarifes` (`ID`, `data_hora`, `user`, `id_dealer`, `id_familia`, `bool_in_bulk`, `cost_price`, `pvp`, `pvpi`, `pv1`, `pv1i`, `pv2`, `pv2i`, `pv3`, `pv3i`, `pv4`, `pv4i`, `historic`, `ultimpreu`, `tipusiva`) VALUES
(1,	'2021-02-02 18:47:00',	'over',	1,	1,	1,	10.89,	13.62,	'1.25',	13.07,	'1.20',	13.07,	'1.20',	13.07,	'1.20',	13.07,	'1.20',	1,	1,	0);

DROP TABLE IF EXISTS `ultimpes`;
CREATE TABLE `ultimpes` (
  `ID` tinyint(3) unsigned NOT NULL COMMENT 'idbascula',
  `pes` int(10) unsigned NOT NULL COMMENT 'pes en grams',
  `preu` int(10) unsigned NOT NULL COMMENT 'preu*100'
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

TRUNCATE `ultimpes`;

DROP TABLE IF EXISTS `urlcodemap`;
CREATE TABLE `urlcodemap` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `encoded` varchar(128) NOT NULL,
  `decoded` varchar(128) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `urlcodemapUIdx1` (`encoded`)
) ENGINE=InnoDB AUTO_INCREMENT=218 DEFAULT CHARSET=utf8;

TRUNCATE `urlcodemap`;
INSERT INTO `urlcodemap` (`id`, `encoded`, `decoded`) VALUES
(1,	'%20',	' '),
(2,	'%21',	'!'),
(3,	'%22',	'\"'),
(4,	'%23',	'#'),
(5,	'%24',	'$'),
(6,	'%25',	'%'),
(7,	'%26',	'&'),
(8,	'%27',	'\''),
(9,	'%28',	'('),
(10,	'%29',	')'),
(11,	'%2A',	'*'),
(12,	'%2B',	'+'),
(13,	'%2C',	','),
(14,	'%2D',	'-'),
(15,	'%2E',	'.'),
(16,	'%2F',	'/'),
(17,	'%30',	'0'),
(18,	'%31',	'1'),
(19,	'%32',	'2'),
(20,	'%33',	'3'),
(21,	'%34',	'4'),
(22,	'%35',	'5'),
(23,	'%36',	'6'),
(24,	'%37',	'7'),
(25,	'%38',	'8'),
(26,	'%39',	'9'),
(27,	'%3A',	':'),
(28,	'%3B',	';'),
(29,	'%3C',	'<'),
(30,	'%3D',	'='),
(31,	'%3E',	'>'),
(32,	'%3F',	'?'),
(33,	'%40',	'@'),
(34,	'%41',	'A'),
(35,	'%42',	'B'),
(36,	'%43',	'C'),
(37,	'%44',	'D'),
(38,	'%45',	'E'),
(39,	'%46',	'F'),
(40,	'%47',	'G'),
(41,	'%48',	'H'),
(42,	'%49',	'I'),
(43,	'%4A',	'J'),
(44,	'%4B',	'K'),
(45,	'%4C',	'L'),
(46,	'%4D',	'M'),
(47,	'%4E',	'N'),
(48,	'%4F',	'O'),
(49,	'%50',	'P'),
(50,	'%51',	'Q'),
(51,	'%52',	'R'),
(52,	'%53',	'S'),
(53,	'%54',	'T'),
(54,	'%55',	'U'),
(55,	'%56',	'V'),
(56,	'%57',	'W'),
(57,	'%58',	'X'),
(58,	'%59',	'Y'),
(59,	'%5A',	'Z'),
(60,	'%5B',	'['),
(61,	'%5C',	'\\'),
(62,	'%5D',	']'),
(63,	'%5E',	'^'),
(64,	'%5F',	'_'),
(65,	'%60',	'`'),
(66,	'%61',	'a'),
(67,	'%62',	'b'),
(68,	'%63',	'c'),
(69,	'%64',	'd'),
(70,	'%65',	'e'),
(71,	'%66',	'f'),
(72,	'%67',	'g'),
(73,	'%68',	'h'),
(74,	'%69',	'i'),
(75,	'%6A',	'j'),
(76,	'%6B',	'k'),
(77,	'%6C',	'l'),
(78,	'%6D',	'm'),
(79,	'%6E',	'n'),
(80,	'%6F',	'o'),
(81,	'%70',	'p'),
(82,	'%71',	'q'),
(83,	'%72',	'r'),
(84,	'%73',	's'),
(85,	'%74',	't'),
(86,	'%75',	'u'),
(87,	'%76',	'v'),
(88,	'%77',	'w'),
(89,	'%78',	'x'),
(90,	'%79',	'y'),
(91,	'%7A',	'z'),
(92,	'%7B',	'{'),
(93,	'%7C',	'|'),
(94,	'%7D',	'}'),
(95,	'%7E',	'~'),
(96,	'%80',	'`'),
(97,	'%82',	'‚'),
(98,	'%83',	'ƒ'),
(99,	'%84',	'„'),
(100,	'%85',	'…'),
(101,	'%86',	'†'),
(102,	'%87',	'‡'),
(103,	'%88',	'ˆ'),
(104,	'%89',	'‰'),
(105,	'%8A',	'Š'),
(106,	'%8B',	'‹'),
(107,	'%8C',	'Œ'),
(108,	'%8E',	'Ž'),
(109,	'%91',	'‘'),
(110,	'%92',	'’'),
(111,	'%93',	'“'),
(112,	'%94',	'”'),
(113,	'%95',	'•'),
(114,	'%96',	'–'),
(115,	'%97',	'—'),
(116,	'%98',	'˜'),
(117,	'%99',	'™'),
(118,	'%9A',	'š'),
(119,	'%9B',	'›'),
(120,	'%9C',	'œ'),
(121,	'%9E',	'ž'),
(122,	'%9F',	'Ÿ'),
(123,	'%A1',	'¡'),
(124,	'%A2',	'¢'),
(125,	'%A3',	'£'),
(126,	'%A4',	'¤'),
(127,	'%A5',	'¥'),
(128,	'%A6',	'¦'),
(129,	'%A7',	'§'),
(130,	'%A8',	'¨'),
(131,	'%A9',	'©'),
(132,	'%AA',	'ª'),
(133,	'%AB',	'«'),
(134,	'%AC',	'¬'),
(135,	'%AE',	'®'),
(136,	'%AF',	'¯'),
(137,	'%B0',	'°'),
(138,	'%B1',	'±'),
(139,	'%B2',	'²'),
(140,	'%B3',	'³'),
(141,	'%B4',	'´'),
(142,	'%B5',	'µ'),
(143,	'%B6',	'¶'),
(144,	'%B7',	'·'),
(145,	'%B8',	'¸'),
(146,	'%B9',	'¹'),
(147,	'%BA',	'º'),
(148,	'%BB',	'»'),
(149,	'%BC',	'¼'),
(150,	'%BD',	'½'),
(151,	'%BE',	'¾'),
(152,	'%BF',	'¿'),
(153,	'%C0',	'À'),
(154,	'%C1',	'Á'),
(155,	'%C2',	'Â'),
(156,	'%C3',	'Ã'),
(157,	'%C4',	'Ä'),
(158,	'%C5',	'Å'),
(159,	'%C6',	'Æ'),
(160,	'%C7',	'Ç'),
(161,	'%C8',	'È'),
(162,	'%C9',	'É'),
(163,	'%CA',	''),
(164,	'%CB',	'Ë'),
(165,	'%CC',	'Ì'),
(166,	'%CD',	'Í'),
(167,	'%CE',	'Î'),
(168,	'%CF',	'Ï'),
(169,	'%D0',	'Ð'),
(170,	'%D1',	'Ñ'),
(171,	'%D2',	'Ò'),
(172,	'%D3',	'Ó'),
(173,	'%D4',	'Ô'),
(174,	'%D5',	'Õ'),
(175,	'%D6',	'Ö'),
(176,	'%D7',	'×'),
(177,	'%D8',	'Ø'),
(178,	'%D9',	'Ù'),
(179,	'%DA',	'Ú'),
(180,	'%DB',	'Û'),
(181,	'%DC',	'Ü'),
(182,	'%DD',	'Ý'),
(183,	'%DE',	'Þ'),
(184,	'%DF',	'ß'),
(185,	'%E0',	'à'),
(186,	'%E1',	'á'),
(187,	'%E2',	'â'),
(188,	'%E3',	'ã'),
(189,	'%E4',	'ä'),
(190,	'%E5',	'å'),
(191,	'%E6',	'æ'),
(192,	'%E7',	'ç'),
(193,	'%E8',	'è'),
(194,	'%E9',	'é'),
(195,	'%EA',	'ê'),
(196,	'%EB',	'ë'),
(197,	'%EC',	'ì'),
(198,	'%ED',	'í'),
(199,	'%EE',	'î'),
(200,	'%EF',	'ï'),
(201,	'%F0',	'ð'),
(202,	'%F1',	'ñ'),
(203,	'%F2',	'ò'),
(204,	'%F3',	'ó'),
(205,	'%F4',	'ô'),
(206,	'%F5',	'õ'),
(207,	'%F6',	'ö'),
(208,	'%F7',	'÷'),
(209,	'%F8',	'ø'),
(210,	'%F9',	'ù'),
(211,	'%FA',	'ú'),
(212,	'%FB',	'û'),
(213,	'%FC',	'ü'),
(214,	'%FD',	'ý'),
(215,	'%FE',	'þ'),
(216,	'%FF',	'ÿ'),
(217,	'+',	' ');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `username` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `ID_Empresa` int(10) unsigned NOT NULL,
  `url_key` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `id_bascula` varchar(255) COLLATE utf8_spanish2_ci NOT NULL DEFAULT '1',
  `bascula_vertical` tinyint(4) NOT NULL DEFAULT 1,
  KEY `ID_Empresa` (`ID_Empresa`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`ID_Empresa`) REFERENCES `Empresa` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

TRUNCATE `users`;
INSERT INTO `users` (`username`, `password`, `ID_Empresa`, `url_key`, `id_bascula`, `bascula_vertical`) VALUES
('Over',	'developmentpassword',	100,	'7979078979877070225d13310b5f1a3fcc3f23f873a53e',	'10',	0);

DROP TABLE IF EXISTS `llistapvp`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `llistapvp` AS select lpad(`productnames`.`ID`,4,0) AS `id`,`productnames`.`value` AS `value`,replace(`tarifes`.`cost_price`,'.',',') AS `cost`,replace(`tarifes`.`pvp`,'.',',') AS `pvp`,replace(`tarifes`.`pv1`,'.',',') AS `pv1`,replace(`tarifes`.`pv2`,'.',',') AS `pv2`,replace(`tarifes`.`pv3`,'.',',') AS `pv3`,replace(`tarifes`.`pv4`,'.',',') AS `pv4`,date_format(`tarifes`.`data_hora`,' %Y %m %d') AS `modificat`,`tarifes`.`data_hora` AS `datacrua` from (`productnames` join `tarifes`) where `tarifes`.`ID` = `productnames`.`ID` and `tarifes`.`ultimpreu` = 1 and `tarifes`.`cost_price` <> '0' order by `productnames`.`ID` <> 0 desc;

DROP TABLE IF EXISTS `Llista_prov`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `Llista_prov` AS select concat('<a href=./prov.php?do=update&id=',`dealers`.`ID`,'>',`urldecoder`(`dealers`.`Value`),'</a>') AS `Proveïdor` from `dealers` where `dealers`.`ID` > 0 order by `dealers`.`Value`;

DROP TABLE IF EXISTS `scalelist`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `scalelist` AS select `productnamesurlencoded`.`ID` AS `id`,`productnamesurlencoded`.`value` AS `value`,concat('1') AS `exist`,concat(replace(if(`tarifes`.`pvp` between '1' and '60',round(`tarifes`.`pvp` * 1,2),`tarifes`.`pvp`),'.',','),if(`tarifes`.`bool_in_bulk` = 1,'€/Kg','€/uni')) AS `formatpvp`,`tarifes`.`bool_in_bulk` AS `bulk`,if(`tarifes`.`pvp` between '1' and '60',round(`tarifes`.`pvp` * 1,2),`tarifes`.`pvp`) AS `pvp` from (`productnamesurlencoded` join `tarifes`) where `tarifes`.`ID` = `productnamesurlencoded`.`ID` and `tarifes`.`ultimpreu` = 1 and `tarifes`.`cost_price` <> '0' order by `productnamesurlencoded`.`ID` <> 0 desc;

-- 2021-02-13 07:08:45
